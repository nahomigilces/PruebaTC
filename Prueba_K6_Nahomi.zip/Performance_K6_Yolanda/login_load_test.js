
import http from 'k6/http';
import { check } from 'k6';
import { SharedArray } from 'k6/data';
import { Trend, Rate, Counter } from 'k6/metrics';

export const error_rate = new Rate('error_rate');
export const login_duration = new Trend('login_duration');
export const failures = new Counter('failures');

const BASE_URL = 'https://fakestoreapi.com';

const users = new SharedArray('usuarios', function() {
  const text = open('data/users.csv');
  const lines = text.trim().split(/\r?\n/);
  lines.shift(); // header
  return lines.map(l => {
    const [username, password] = l.split(',');
    return { username: username.trim(), password: password.trim() };
  });
});

const RATE = Number(__ENV.RATE || 20);
const DURATION = __ENV.DURATION || '3m';
const PRE_VUS = Number(__ENV.VUS || 50);
const MAX_VUS = Number(__ENV.MAX_VUS || 100);

export const options = {
  scenarios: {
    login_rate: {
      executor: 'constant-arrival-rate',
      rate: RATE,
      timeUnit: '1s',
      duration: DURATION,
      preAllocatedVUs: PRE_VUS,
      maxVUs: MAX_VUS,
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<1500'],
    checks: ['rate>0.97'],
    error_rate: ['rate<0.03'],
  },
};

export default function () {
  const u = users[__ITER % users.length];
  const res = http.post(`${BASE_URL}/auth/login`, JSON.stringify({ username: u.username, password: u.password }), {
    headers: { 'Content-Type': 'application/json' },
    tags: { name: 'POST /auth/login' }
  });

  login_duration.add(res.timings.duration);
  const ok = check(res, {
    'status 200': (r) => r.status === 200,
    'token presente': (r) => { try { const j = r.json(); return j && (j.token || j.Token || j.access_token); } catch(e){ return false; } },
    'duración <= 1500ms': (r) => r.timings.duration <= 1500,
  });
  if (!ok) { error_rate.add(1); failures.add(1); } else { error_rate.add(0); }
}

export function handleSummary(data) {
  const rateOk = data.metrics.http_req_duration.thresholds['p(95)<1500']?.ok;
  const checksOk = data.metrics.checks.thresholds['rate>0.97']?.ok;
  const errOk = data.metrics.error_rate.thresholds['rate<0.03']?.ok;

  const lines = [];
  lines.push('RESULTADOS DE LA PRUEBA');
  lines.push('=======================');
  lines.push(`Escenario: constant-arrival-rate @ ${RATE} req/s, duración ${DURATION}`);
  lines.push(`Total requests: ${data.metrics.http_reqs.values.count}`);
  lines.push(`RPS (prom): ${data.metrics.http_reqs.values.rate.toFixed(2)}`);
  lines.push(`Duración p(95): ${Math.round(data.metrics.http_req_duration.values['p(95)'])} ms`);
  const errPct = (1 - data.metrics.checks.values.rate) * 100;
  lines.push(`Errores (checks fallidos): ${errPct.toFixed(2)}%`);
  lines.push(`Error Rate métrica: ${(data.metrics.error_rate.values.rate*100).toFixed(2)}%`);
  lines.push('');
  lines.push('Thresholds:');
  lines.push(` - http_req_duration p(95)<1500 => ${rateOk ? 'OK' : 'FALLÓ'}`);
  lines.push(` - checks rate>0.97 => ${checksOk ? 'OK' : 'FALLÓ'}`);
  lines.push(` - error_rate<0.03 => ${errOk ? 'OK' : 'FALLÓ'}`);

  return {
    'reports/textSummary.txt': lines.join('\n'),
    'reports/summary.json': JSON.stringify(data, null, 2),
  };
}


#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Uso: $0 <USER> <REPO> [TOKEN]"
  exit 1
fi
USER="$1"
REPO="$2"
TOKEN="${3:-}"

if [ -n "$TOKEN" ]; then
  ORIGIN_URL="https://${TOKEN}@github.com/${USER}/${REPO}.git"
else
  ORIGIN_URL="https://github.com/${USER}/${REPO}.git"
fi

git init
git add .
git commit -m "feat: prueba de carga k6 para login fakestoreapi"
git branch -M main

git remote remove origin 2>/dev/null || true

git remote add origin "$ORIGIN_URL"

git push -u origin main

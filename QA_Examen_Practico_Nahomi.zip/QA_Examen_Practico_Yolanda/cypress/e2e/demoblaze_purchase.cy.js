
/// <reference types="cypress" />

describe('Flujo de compra - Demoblaze', () => {
  const orderData = {
    name: 'Yolanda QA',
    country: 'Ecuador',
    city: 'Guayaquil',
    card: '4111111111111111',
    month: '12',
    year: '2028'
  };

  it('Agrega dos productos, visualiza carrito y finaliza la compra', () => {
    // Agregar 2 productos distintos por ID (1 y 2 son ejemplos válidos en Demoblaze)
    cy.addProductById(1);
    cy.addProductById(2);

    // Ir al carrito
    cy.visit('/');
    cy.get('#cartur').should('be.visible').click();

    // Validar que existan al menos 2 ítems en el carrito
    cy.get('#tbodyid tr').should('have.length.at.least', 2);

    // Finalizar compra
    cy.contains('button', 'Place Order').should('be.visible').click();

    // Completar formulario del modal
    cy.get('#name').type(orderData.name);
    cy.get('#country').type(orderData.country);
    cy.get('#city').type(orderData.city);
    cy.get('#card').type(orderData.card);
    cy.get('#month').type(orderData.month);
    cy.get('#year').type(orderData.year);

    cy.contains('button', 'Purchase').click();

    // Validar confirmación
    cy.contains('h2', 'Thank you for your purchase!').should('be.visible');
    cy.get('.sweet-alert, .confirm').contains('OK').click({ force: true });
  });
});

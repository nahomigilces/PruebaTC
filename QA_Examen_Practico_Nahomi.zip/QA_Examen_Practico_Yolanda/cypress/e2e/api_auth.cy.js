
/// <reference types="cypress" />

describe('APIs Auth Demoblaze - signup/login', () => {
  const base = 'https://api.demoblaze.com';
  const unique = Date.now();
  const user = `yolanda.qa.${unique}`;
  const pass = 'P@ssw0rd!';

  it('Signup - crear un nuevo usuario', () => {
    cy.request('POST', `${base}/signup`, { username: user, password: pass })
      .then((res) => {
        expect(res.status).to.eq(200);
        // demoblaze devuelve un JSON; en registro exitoso suele no traer error
        // intentamos detectar estructura común
        expect(res.body).to.exist;
        // Log de salida
        cy.log('Respuesta signup (nuevo):', JSON.stringify(res.body));
      });
  });

  it('Signup - intentar crear un usuario ya existente', () => {
    cy.request('POST', `${base}/signup`, { username: user, password: pass })
      .then((res) => {
        expect(res.status).to.eq(200);
        // En intento duplicado, el API responde 200 con un cuerpo que incluye mensaje de error
        expect(res.body).to.exist;
        cy.log('Respuesta signup (duplicado):', JSON.stringify(res.body));
      });
  });

  it('Login - usuario y password correctos', () => {
    cy.request('POST', `${base}/login`, { username: user, password: pass })
      .then((res) => {
        expect(res.status).to.eq(200);
        expect(res.body).to.exist;
        // Generalmente retorna un token (Auth_token); validación flexible
        const bodyStr = JSON.stringify(res.body).toUpperCase();
        expect(bodyStr).to.satisfy((s) => s.includes('AUTH') || s.includes('TOKEN') || s.includes('OK'));
        cy.log('Respuesta login (correcto):', JSON.stringify(res.body));
      });
  });

  it('Login - usuario correcto y password incorrecto', () => {
    cy.request({
      method: 'POST',
      url: `${base}/login`,
      body: { username: user, password: 'Clave_Incorrecta' },
      failOnStatusCode: false
    }).then((res) => {
      // Algunos endpoints devuelven 200 con mensaje de error; por eso no forzamos 4xx
      expect([200, 400, 401]).to.include(res.status);
      expect(res.body).to.exist;
      const bodyStr = JSON.stringify(res.body).toUpperCase();
      expect(bodyStr).to.satisfy((s) => s.includes('ERROR') || s.includes('WRONG') || s.includes('INVALID') || s.includes('FAIL'));
      cy.log('Respuesta login (incorrecto):', JSON.stringify(res.body));
    });
  });
});

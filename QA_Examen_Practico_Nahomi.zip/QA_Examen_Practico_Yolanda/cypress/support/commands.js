
// Custom Commands for Demoblaze
Cypress.Commands.add('addProductById', (id) => {
  cy.visit(`/prod.html?idp_=${id}`);
  cy.contains('a', 'Add to cart').should('be.visible').click();
  // handle alert confirmation message from demoblaze
  cy.on('window:alert', (txt) => {
    // optional assertion on alert text
    expect(txt).to.match(/added\./i);
  });
});

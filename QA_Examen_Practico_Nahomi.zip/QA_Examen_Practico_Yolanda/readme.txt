QA Examen práctico – Entrega automatizada (Cypress)
===================================================

Contenido
---------
- Flujo E2E de compra en https://www.demoblaze.com/
- Pruebas de APIs (signup/login) contra https://api.demoblaze.com/
- Reportería Mochawesome

Requisitos
----------
1) Node.js 18+ y npm
2) (Opcional) Google Chrome/Edge para ejecución interactiva

Instalación
-----------
```
npm install
```

Ejecución
---------
- Abrir Cypress: `npm run open`
- Solo E2E: `npm run test:e2e`
- Solo APIs: `npm run test:api`
- Todo: `npm run test:all`

Reportes
--------
Este proyecto incluye `cypress-mochawesome-reporter`. Tras `npm run test:*` se genera el HTML en `./cypress/reports/html` (si no aparece, verifique la versión de reporter y configuración en `cypress.config.js`).

Estructura
----------
- `cypress/e2e/demoblaze_purchase.cy.js` → Flujo E2E (agregar 2 productos, ver carrito, comprar)
- `cypress/e2e/api_auth.cy.js` → Signup/Login con casos: nuevo usuario, duplicado, login correcto e incorrecto
- `cypress/support/*` → Comandos y registro del reporter
- `cypress/fixtures/users.json` → Datos de ejemplo
- `postman/Demoblaze_Auth.postman_collection.json` → Colección alternativa para probar los endpoints

Parámetros y notas
------------------
- El test E2E usa IDs de productos 1 y 2 como ejemplos. Pueden cambiar si el sitio actualiza el catálogo; si falla, probar otros IDs (por ejemplo 3, 4...).
- Los endpoints de Demoblaze pueden devolver 200 incluso en error. Las aserciones en API incluyen validaciones flexibles del cuerpo.

Versionado
----------
Fecha de preparación: 2026-03-10
Autor: Yolanda Gilces (Soporte Corporativo)
